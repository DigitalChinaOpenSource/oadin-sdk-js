// const express = require('express');
const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const os = require('os');
const axios = require('axios');
const EventEmitter = require('events');
const _ = require('lodash');
const { execFile, spawn } = require('child_process');
const { promises: fsPromises } = require("fs");

const schemas = require('./schema.js');
const tools = require('./tools.js');
const { logAndConsole, downloadFile, downloadFileWithProgress, getOadinExecutablePath, runInstallerByPlatform, isHealthy } = require('./tools.js');
const { createAxiosInstance, requestWithSchema } = require('./axiosInstance.js')
const { MAIN_VERSION, SUB_VERSION, WIN_OADIN_PATH, MAC_OADIN_PATH, PLATFORM_CONFIG, OADIN_HEALTH, OADIN_ENGINE_PATH, } = require('./constants.js');

class Oadin {
  constructor() {
    this.version = null;
    this.client = null;
    this.downloadConfig = null;
    this.defaultEmbedModel = "";
    this.defaultChatModel = "";
  }

  async initClient(version) {
    this.version = version;
    this.client = createAxiosInstance(version);
    logAndConsole('info', `Oadin axios 实例已初始化，版本: ${version}`);
  }

  async ensureClient() {
    if (!this.client) {
      const version = await tools.getOadinVersion();
      if (!version) throw new Error('无法获取 Oadin 版本，无法初始化 axios 实例');
      this.initClient(version);
    }
  }

  async _requestWithSchema({ method, url, data, schema }) {
    await this.ensureClient();
    logAndConsole('info', `请求API: ${method.toUpperCase()} ${url}`);
    return await requestWithSchema({ method, url, data, schema, instance: this.client });
  }

  // 检查 Oadin 服务是否启动
  async isOadinAvailable(retries = 5, interval = 1000) {
    logAndConsole('info', '检测Oadin服务可用性...');
    const fibArr = tools.fibonacci(retries, interval);
    for (let attempt = 0; attempt < retries; attempt++) {
      try {
        // const [healthRes, engineHealthRes] = await Promise.all([
        //   axios.get(OADIN_HEALTH),
        //   axios.get(OADIN_ENGINE_PATH)
        // ]);
        const healthRes = await axios.get(OADIN_HEALTH);
        const healthOk = isHealthy(healthRes.status);
        // const engineOk = isHealthy(engineHealthRes.status);
        // logAndConsole('info', `/health: ${healthOk ? '正常' : '异常'}, /engine/health: ${engineOk ? '正常' : '异常'}`);
        // if (healthOk && engineOk) return true;
        logAndConsole('info', `/health: ${healthOk ? '正常' : '异常'}`);
        if (healthOk) return true;
      } catch (err) {
        logAndConsole('warn', `健康检查失败: ${err.message}`);
      }
      if (attempt < retries - 1) {
        await new Promise(r => setTimeout(r, fibArr[attempt]));
      }
    }
    logAndConsole('warn', 'Oadin服务不可用');
    return false;
  }

  // 检查用户目录是否存在 Oadin.exe, 存在则保证初始化 axios 实例
  async isOadinExisted() {
    const dest = getOadinExecutablePath();
    const existed = fs.existsSync(dest);
    logAndConsole('info', `检测Oadin可执行文件是否存在: ${dest}，结果: ${existed}`);
    if (existed) {
      await this.isOadinExistedAndUpdate(this.downloadConfig?.version);
      await this.ensureClient();
    }
    return existed;
  }

  async stopOadin() {
    return new Promise((resolve) => {
      const platform = tools.getPlatform();
      // const userDir = os.homedir();
      // const oadinDir = path.join(userDir, 'Oadin');
      const oadinDir = WIN_OADIN_PATH;
      logAndConsole('info', `尝试停止 Oadin 服务，平台: ${platform}`);

      let command;
      let args;

      if (platform === 'win32') {
        command = 'cmd.exe';
        args = ['/c', 'oadin.exe', 'server', 'stop']; // 在 Windows 上直接调用 oadin.exe
        // 确保 oadinDir 在 PATH 中，或者使用绝对路径
        const originalPath = process.env.PATH;
        if (!process.env.PATH.includes(oadinDir)) {
          process.env.PATH = `${process.env.PATH}${path.delimiter}${oadinDir}`;
        }
        execFile(command, args, { windowsHide: true }, (error, stdout, stderr) => {
          process.env.PATH = originalPath; // 恢复 PATH
          if (error) {
            logAndConsole('error', `停止 Oadin 服务失败: ${error.message}, stderr: ${stderr.toString()}`);
            return resolve(false);
          }
          logAndConsole('info', `Oadin 服务停止命令输出: ${stdout.toString()}`);
          resolve(true); 
        });
      } else if (platform === 'darwin') {
        command = MAC_OADIN_PATH; // /usr/local/bin/oadin
        args = ['server', 'stop'];
        execFile(command, args, { timeout: 5000 }, (error, stdout, stderr) => {
          if (error) {
            logAndConsole('error', `停止 Oadin 服务失败: ${error.message}, stderr: ${stderr.toString()}`);
            return resolve(false);
          }
          logAndConsole('info', `Oadin 服务停止命令输出: ${stdout.toString()}`);
          resolve(true); 
        });
      } else {
        logAndConsole('warn', `不支持的平台，无法停止 Oadin 服务。`);
        return resolve(false);
      }
    });
  }

  getOadinInstallerPath() {
    const platform = tools.getPlatform();
    if (platform == "unsupported") { return null }
    else if (platform === 'win32') { return PLATFORM_CONFIG.win32.downloadUrl }
    else if (platform === 'darwin') { return PLATFORM_CONFIG.darwin.downloadUrl };
  }

  // 私有方法：仅下载
  async _downloadFile(url, dest, options, retries = 3) {
    logAndConsole('info', `准备下载文件: ${url} 到 ${dest}`);
    return await downloadFile(url, dest, options, retries);
  }

  // 运行安装包
  async _runOadinInstaller(installerPath) {
    const platform = tools.getPlatform();
    logAndConsole('info', `运行安装包: ${installerPath}，平台: ${platform}`);
    try {
      await runInstallerByPlatform(installerPath);
      logAndConsole('info', '安装包运行成功');
      return true;
    } catch (err) {
      logAndConsole('error', '安装包运行失败：' + err.message);
      return false;
    }
  }

  async downloadOadin(retries = 3) {
    try {
      const platform = tools.getPlatform();
      if (platform === 'unsupported' || !PLATFORM_CONFIG[platform]) {
        logAndConsole('error', '不支持的平台');
        return false;
      }
      const { downloadUrl, installerFileName, userAgent } = PLATFORM_CONFIG[platform];
      // Windows：C:\Users\<用户名>\AppData\Local\Temp
      // macOS: /tmp
      const tempDir = os.tmpdir();
      const destDir = path.join(tempDir, 'OadinInstaller');
      logAndConsole('info', `OadinInstaller 临时下载目录: ${destDir}`);
      const dest = path.join(destDir, installerFileName);
      const options = {
        headers: {
          'User-Agent': userAgent,
        },
      };
      let targetSubVersion = SUB_VERSION;
      if (this.downloadConfig && this.downloadConfig.version !== 'xxxxx') {
        targetSubVersion = this.downloadConfig.version;
      }
      const downloadUrlReplaced = downloadUrl.replace('latest', targetSubVersion);
      logAndConsole('info', `downloadOadin url: ${downloadUrlReplaced}`);
      const downloadOk = await this._downloadFile(downloadUrlReplaced, dest, options, retries);
      if (downloadOk) {
        const installResult = await this._runOadinInstaller(dest);
        if (installResult) {
          await this.ensureClient();
        }
        return installResult;
      } else {
        logAndConsole('error', '三次下载均失败，放弃安装。');
        return false;
      }
    } catch (err) {
      logAndConsole('error', '下载或安装 Oadin 失败: ' + err.message);
      return false;
    }
  }

  // 启动 Oadin 服务
  async startOadin() {
    await this.ensureClient();
    const alreadyRunning = await this.isOadinAvailable(2, 1000);
    if (alreadyRunning) {
      logAndConsole('info', '[startOadin] Oadin 在运行中');
      return true;
    }
    return new Promise((resolve, reject) => {
      const platform = tools.getPlatform();
      // 1.0 相关版本是安装在用户目录，且增加了环境变量
      const userDir = os.homedir();
      const oadinDirOld = path.join(userDir, 'Oadin');
      // 2.0 相关版本是安装在系统目录
      const oadinDir = WIN_OADIN_PATH;
      logAndConsole('info', `oadinDir: ${oadinDir}`);
      if (platform === "unsurported") return reject(new Error(`不支持的平台`));
      if (platform === 'win32') {
        if (process.env.PATH.includes(oadinDirOld)) {
          // 删除旧的环境变量
          process.env.PATH = process.env.PATH.split(path.delimiter).filter(p => p !== oadinDirOld).join(path.delimiter);
        }
        if (!process.env.PATH.includes(oadinDir)) {
          process.env.PATH = `${process.env.PATH}${path.delimiter}${oadinDir}`;
          logAndConsole('info', '添加到临时环境变量');
        }
        // const command = 'cmd.exe';
        // const args = ['/c', 'start-oadin.bat'];
        // logAndConsole('info', `正在运行命令: ${command} ${args.join(' ')}`);
        // 直接调用 oadin.exe
        const command = path.join(oadinDir, 'oadin.exe');
        const args = ['server', 'start', '-d'];
        logAndConsole('info', `正在运行命令: ${command} ${args.join(' ')}`);
        execFile(command, args, { windowsHide: true }, async (error, stdout, stderr) => {
          if (error) logAndConsole('error', 'oadin server start:error ' + error);
          if (stdout) logAndConsole('info', 'oadin server start:stdout: ' + stdout.toString());
          if (stderr) logAndConsole('error', 'oadin server start:stderr: ' + stderr.toString());
          const output = (stdout + stderr).toString().toLowerCase();
          if (error || output.includes('error')) {
            return resolve(false);
          }
          const available = await this.isOadinAvailable(5, 1500);
          return resolve(available);
        });
      } else if (platform === 'darwin') {
        try {
          if (!process.env.PATH.split(':').includes('/usr/local/bin')) {
            process.env.PATH = `/usr/local/bin:${process.env.PATH}`;
            logAndConsole('info', '已将 /usr/local/bin 添加到 PATH');
          }
          let child;
          let stderrContent = '';
          child = spawn('/usr/local/bin/oadin', ['server', 'start', '-d'], {
            stdio: ['ignore', 'pipe', 'pipe'],
            windowsHide: true,
          });
          child.stdout.on('data', (data) => {
            if (data.toString().includes('server start successfully')) {
              //TODO：获取退出状态码
              logAndConsole('info', 'Oadin 服务启动成功');
              resolve(true);
            }
            logAndConsole('info', `stdout: ${data}`);
          });
          child.stderr.on('data', (data) => {
            const errorMessage = data.toString().trim();
            stderrContent += errorMessage + '\n';
            logAndConsole('error', `stderr: ${errorMessage}`);
          });
          child.on('error', (err) => {
            logAndConsole('error', `❌ 启动失败: ${err.message}`);
            if (err.code === 'ENOENT') {
              logAndConsole('error', '未找到oadin可执行文件，请检查下载是否成功或环境变量未生效');
            }
            resolve(false);
          });
          child.on('close', (code) => {
            if (stderrContent.includes('Install model engine failed')){
              logAndConsole('error', '❌ 启动失败: 模型引擎安装失败。');
              resolve(false);
            } else if (code === 0) {
              logAndConsole('info', '进程退出，正在检查服务状态...');
            } else {
              logAndConsole('error', `❌ 启动失败，退出码: ${code}`);
              resolve(false);
            }
          });
          child.unref();
        } catch (error) {
          logAndConsole('error', '启动 Oadin 服务异常: ' + error.message);
          resolve(false);
        }
      }
    });
  }
  
  // 查看当前服务
  async getServices() {
    return this._requestWithSchema({
      method: 'get',
      url: '/service',
      schema: { response: schemas.getServicesSchema }
    });
  }

  // 创建新服务
  async installService(data) {
    return this._requestWithSchema({
      method: 'post',
      url: '/service',
      data,
      schema: { request: schemas.installServiceRequestSchema, response: schemas.ResponseSchema }
    });
  }

  // 更新服务
  async updateService(data) {
    return this._requestWithSchema({
      method: 'put',
      url: '/service',
      data,
      schema: { request: schemas.updateServiceRequestSchema, response: schemas.ResponseSchema }
    });
  }

  // 查看当前模型
  async getModels() {
    return this._requestWithSchema({
      method: 'get',
      url: '/model',
      schema: { response: schemas.getModelsSchema }
    });
  }

  // 安装新模型
  async installModel(data) {
    return this._requestWithSchema({
      method: 'post',
      url: '/model',
      data,
      schema: { request: schemas.installModelRequestSchema, response: schemas.ResponseSchema }
    });
  }

  async deleteModel(data) {
    return this._requestWithSchema({
      method: 'delete',
      url: '/model',
      data,
      schema: { request: schemas.deleteModelRequestSchema, response: schemas.ResponseSchema }
    });
  }

  async installModelStream(data) {
    const version = await tools.getOadinVersion();
    const client = axios.create({
      baseURL: `http://localhost:16688/oadin/${version}`,
      headers: {"Content-Type": "application/json" },
    })
    const config = { responseType: 'stream' };
    try {
      const res = await client.post('/model/stream', data, config);
      const eventEmitter = new EventEmitter();

      res.data.on('data', (chunk) => {
        try {
          // 解析流数据
          const rawData = chunk.toString().trim();
          const jsonString = rawData.startsWith('data:') ? rawData.slice(5) : rawData;
          const response = JSON.parse(jsonString);

          eventEmitter.emit('data', rawData);
          if (response.status === 'success') {
            eventEmitter.emit('end', rawData);
          }
          if (response.status === 'canceled') {
            eventEmitter.emit('canceled', rawData);
          }
          if (response.status === 'error') {
            eventEmitter.emit('end', rawData);
          }

        } catch (err) {
          eventEmitter.emit('error', `解析流数据失败: ${err.message}`);
        }
      });

      res.data.on('error', (err) => {
        eventEmitter.emit('error', `流式响应错误: ${err.message}`);
      });

      res.data.on('end', () => {
        eventEmitter.emit('end');
      });

      return eventEmitter; // 返回 EventEmitter 实例
    } catch (error) {
      return {
        code: 400,
        msg: error.response?.data?.message || error.message || '请求失败',
        data: null,
      }
    }
  }

  async cancelInstallModel(data) {
    return this._requestWithSchema({
      method: 'post',
      url: '/model/stream/cancel',
      data,
      schema: { request: schemas.cancelModelStreamRequestSchema, response: schemas.ResponseSchema }
    });
  }

  // 查看服务提供商
  async getServiceProviders() {
    return this._requestWithSchema({
      method: 'get',
      url: '/service_provider',
      schema: { response: schemas.getServiceProvidersSchema }
    });
  }

  // 新增服务提供商
  async installServiceProvider(data) {
    return this._requestWithSchema({
      method: 'post',
      url: '/service_provider',
      data,
      schema: { request: schemas.installServiceProviderRequestSchema, response: schemas.ResponseSchema }
    });
  }

  // 更新服务提供商
  async updateServiceProvider(data) {
    return this._requestWithSchema({
      method: 'put',
      url: '/service_provider',
      data,
      schema: { request: schemas.updateServiceProviderRequestSchema, response: schemas.ResponseSchema }
    });
  }

  // 删除服务提供商
  async deleteServiceProvider(data) {
    return this._requestWithSchema({
      method: 'post',
      url: '/service_provider',
      data,
      schema: { request: schemas.deleteServiceProviderRequestSchema, response: schemas.ResponseSchema }
    });
  }

  // 导入配置文件
  async importConfig(filePath) {
    try {
      const data = await fsPromises.readFile(filePath, 'utf8');
      return this._requestWithSchema({
        method: 'post',
        url: '/service/import',
        data,
        schema: { response: schemas.ResponseSchema }
      });
    } catch (error) {
      return { code: 400, msg: error.message, data: null };
    }
  }

  // 导出配置文件
  async exportConfig(data = {}) {
    // 只做文件写入，http部分用统一schema校验
    const result = await this._requestWithSchema({
      method: 'post',
      url: '/service/export',
      data,
      schema: { request: schemas.exportRequestSchema, response: schemas.ResponseSchema }
    });
    if (result.code === 200) {
      try {
        const userDir = os.homedir();
        const destDir = path.join(userDir, 'Oadin');
        const dest = path.join(destDir, '.oadin');
        tools.ensureDirWritable(destDir);
        const fileContent = JSON.stringify(result.data, null, 2);
        fs.writeFileSync(dest, fileContent);
        console.log(`已将生成文件写入到 ${dest}`);
      } catch (error) {
        return { code: 400, msg: error.message, data: null };
      }
    }
    return result;
  }

  // 获取推荐模型列表
  async getModelsRecommended() {
    return this._requestWithSchema({
      method: 'get',
      url: '/model/recommend',
      schema: { response: schemas.recommendModelsResponse }
    });
  }

  // getModelsSupported
  async getModelsSupported(data) {
    return this._requestWithSchema({
      method: 'get',
      url: '/model/support',
      data,
      schema: { request: schemas.getModelsSupported, response: schemas.getSupportModelResponseSchema }
    });
  }

  // chat服务（支持流式和非流式）
  async chat(data) {
    const stream = data.stream;
    if (!stream) {
      // 非流式
      return this._requestWithSchema({ method: 'post', url: 'services/chat', data });
    }
    if (this.defaultChatModel && data.model !== this.defaultChatModel) {
      data.model = this.defaultChatModel;
    }
    // 流式
    try {
      const version = await tools.getOadinVersion();
      const client = axios.create({
        baseURL: `http://localhost:16688/oadin/${version}`,
        headers: {"Content-Type": "application/json" },
      });
      const config = { responseType: 'stream' };
      const res = await client.post('services/chat', data, config);
      const eventEmitter = new EventEmitter();
      res.data.on('data', (chunk) => {
        try {
          let rawData = _.isString(chunk) ? _.trim(chunk) : _.trim(chunk.toString());
          let jsonString = _.startsWith(rawData, 'data:') ? rawData.slice(5) : rawData;
          jsonString = _.trim(jsonString);
          if (_.isEmpty(jsonString)) {
            throw new Error('收到空的流数据');
          }
          const response = JSON.parse(jsonString);
          eventEmitter.emit('data', response);
        } catch (err) {
          eventEmitter.emit('error', `解析流数据失败: ${err.message}`);
        }
      });
      res.data.on('error', (err) => {
        eventEmitter.emit('error', `流式响应错误: ${err.message}`);
      });
      res.data.on('end', () => {
        eventEmitter.emit('end'); // 触发结束事件
      });

      // 增加取消回调   eventEmitter.emit("cancel");
      eventEmitter.on('cancel', () => {
        logAndConsole('info', '手动取消流式响应');
        res.data.destroy(); // 销毁流
      });

      return eventEmitter;
    } catch (error) {
      return { code: 400, msg: error.response?.data?.message || error.message, data: null };
    }
  }

  // 生文服务（支持流式和非流式）
  async generate(data) {
    const stream = data.stream;
    if (!stream) {
      return this._requestWithSchema({ method: 'post', url: 'services/generate', data });
    }
    try {
      const version = await tools.getOadinVersion();
      const client = axios.create({
        baseURL: `http://localhost:16688/oadin/${version}`,
        headers: {"Content-Type": "application/json" },
      });
      const config = { responseType: 'stream' };
      const res = await client.post('services/generate', data, config);
      const eventEmitter = new EventEmitter();
      res.data.on('data', (chunk) => {
        try {
          let rawData = _.isString(chunk) ? _.trim(chunk) : _.trim(chunk.toString());
          let jsonString = _.startsWith(rawData, 'data:') ? rawData.slice(5) : rawData;
          jsonString = _.trim(jsonString);
          if (_.isEmpty(jsonString)) {
            throw new Error('收到空的流数据');
          }
          const response = JSON.parse(jsonString);
          eventEmitter.emit('data', response);
        } catch (err) {
          eventEmitter.emit('error', `解析流数据失败: ${err.message}`);
        }
      });
      res.data.on('error', (err) => {
        eventEmitter.emit('error', `流式响应错误: ${err.message}`);
      });
      res.data.on('end', () => {
        eventEmitter.emit('end'); // 触发结束事件
      });

      return eventEmitter;
    } catch (error) {
      return { code: 400, msg: error.response?.data?.message || error.message, data: null };
    }
  }
  
  // 生图服务
  async textToImage(data) {
    return this._requestWithSchema({
      method: 'post',
      url: '/services/text-to-image',
      data,
      schema: { request: schemas.textToImageRequest, response: schemas.textToImageResponse }
    });
  }

  // embed服务
  async embed(data) {
    if (this.defaultEmbedModel && data.model !== this.defaultEmbedModel) {
      data.model = this.defaultEmbedModel;
    }
    return this._requestWithSchema({
      method: 'post',
      url: '/services/embed',
      data,
      // schema: { request: schemas.embeddingRequest, response: schemas.embeddingResponse }
    });
  }

  // 用于一键安装 Oadin 和 导入配置
  // TODO：记录日志
  async OadinInit(path){
    const isOadinAvailable = await this.isOadinAvailable();
    if (isOadinAvailable) {
      logAndConsole('info','✅ Oadin 服务已启动，跳过安装。');
      return true;
    }
    
    const isOadinExisted = await this.isOadinExisted();
    if (!isOadinExisted) {
      const downloadSuccess = await this.downloadOadin();
      if (!downloadSuccess) {
        logAndConsole('error','❌ 下载 Oadin 失败，请检查网络连接或手动下载。');
        return false;
      }
    } else {
      logAndConsole('info','✅ Oadin 已存在，跳过下载。');
    }

    const installSuccess = await this.startOadin();
    if (!installSuccess) {
      logAndConsole('error','❌ 启动 Oadin 服务失败，请检查配置或手动启动。');
      return false;
    } else {
      logAndConsole('info','✅ Oadin 服务已启动。');
    }

    const importSuccess = await this.importConfig(path);
    if (!importSuccess) {
      logAndConsole('error','❌ 导入配置文件失败。');
      return false;
    } else {
      logAndConsole('info','✅ 配置文件导入成功。');
    }
    return true;
  }

  // 下载 Oadin 并支持进度回调 类似于下列函数
  // onProgress = function(downloaded, total) {
  //   if (total > 0) {
  //     logAndConsole('info', `下载进度: ${((downloaded / total) * 100).toFixed(2)}%`);
  //   }
  // };
  async DownloadOadinStream(onProgress) {
    try {
      const platform = tools.getPlatform();
      if (platform === 'unsupported' || !PLATFORM_CONFIG[platform]) {
        logAndConsole('error', '不支持的平台');
        return false;
      }
      const { downloadUrl, installerFileName, userAgent } = PLATFORM_CONFIG[platform];
      const userDir = os.homedir();
      const destDir = path.join(userDir, 'OadinInstaller');
      const dest = path.join(destDir, installerFileName);
      const options = {
        headers: {
          'User-Agent': userAgent,
        },
      };
      const downloadOk = await downloadFileWithProgress(downloadUrl, dest, options, 1, onProgress);
      if (downloadOk) {
        const installResult = await this._runOadinInstaller(dest);
        if (installResult) {
          await this.ensureClient();
        }
        return installResult;
      } else {
        logAndConsole('error', '下载失败，放弃安装。');
        return false;
      }
    } catch (err) {
      logAndConsole('error', '下载或安装 Oadin 失败: ' + err.message);
      return false;
    }
  }

  // 下载 engine 并支持进度回调
  // data {"engineName":"ollama&openvino&llamacpp"}
  async downloadEngineStream(data) {
    const stream = data.stream;
    if (!stream) {
      return this._requestWithSchema({ method: 'post', url: 'engine/download/streamEngine', data });
    }
    try {
      const version = this.version || await tools.getOadinVersion();
      const client = axios.create({
        baseURL: `http://localhost:16688/oadin/${version}`,
        headers: {"Content-Type": "application/json" },
      });
      const config = { responseType: 'stream' };
      const res = await client.post('engine/download/streamEngine', data, config);
      const eventEmitter = new EventEmitter();
      res.data.on('data', (chunk) => {
        try {
          let rawData = _.isString(chunk) ? _.trim(chunk) : _.trim(chunk.toString());
          let jsonString = _.startsWith(rawData, 'data:') ? rawData.slice(5) : rawData;
          jsonString = _.trim(jsonString);
          if (_.isEmpty(jsonString)) {
            throw new Error('收到空的流数据');
          }
          const response = JSON.parse(jsonString);
          eventEmitter.emit('data', response);
        } catch (err) {
          eventEmitter.emit('error', `解析流数据失败: ${err.message}`);
        }
      });
      res.data.on('error', (err) => {
        eventEmitter.emit('error', `流式响应错误: ${err.message}`);
      });
      res.data.on('end', () => {
        eventEmitter.emit('end'); // 触发结束事件
      });

      return eventEmitter;
    } catch (error) {
      return { code: 400, msg: error.response?.data?.message || error.message, data: null };
    }
  }

  // 下载 model 并支持进度回调
  // data {"engineName":"ollama&openvino&llamacpp", "modelName":"your_model_name", "modelType":"chat&generate&embed&speech-to-text"}
  async downloadModelStream(data) {
    const stream = data.stream;
    if (!stream) {
      return this._requestWithSchema({ method: 'post', url: 'engine/download/streamModel', data });
    }
    try {
      const version = this.version || await tools.getOadinVersion();
      const client = axios.create({
        baseURL: `http://localhost:16688/oadin/${version}`,
        headers: {"Content-Type": "application/json" },
      });
      const config = { responseType: 'stream' };
      const res = await client.post('engine/download/streamModel', data, config);
      const eventEmitter = new EventEmitter();
      res.data.on('data', (chunk) => {
        try {
          let rawData = _.isString(chunk) ? _.trim(chunk) : _.trim(chunk.toString());
          let jsonString = _.startsWith(rawData, 'data:') ? rawData.slice(5) : rawData;
          jsonString = _.trim(jsonString);
          if (_.isEmpty(jsonString)) {
            throw new Error('收到空的流数据');
          }
          const response = JSON.parse(jsonString);
          eventEmitter.emit('data', response);
        } catch (err) {
          eventEmitter.emit('error', `解析流数据失败: ${err.message}`);
        }
      });
      res.data.on('error', (err) => {
        eventEmitter.emit('error', `流式响应错误: ${err.message}`);
      });
      res.data.on('end', () => {
        eventEmitter.emit('end'); // 触发结束事件
      });

      return eventEmitter;
    } catch (error) {
      return { code: 400, msg: error.response?.data?.message || error.message, data: null };
    }
  }

  // 3通过奥丁检查电脑配置
  async getDownloadConfig(path){
    try {
      logAndConsole('info', '读取下载配置文件: ' + path);
      this.downloadConfig = JSON.parse(fs.readFileSync(path, 'utf-8'));
      return true;
    } catch (error) {
      logAndConsole('error', '读取下载配置失败: ' + error.message);
      return false;
    }
  }

  // 4下载合适的引擎
  async DownloadEngine(){
    if (!this.downloadConfig) {
      logAndConsole('error', '下载配置未加载');
      return false;
    }
    try {
      let result = true;
      for (const engine of this.downloadConfig.support_engines) {
        const res = await this.downloadEngineStream({engineName: engine});
        if (res.code !== 200) {
          logAndConsole('error', '下载引擎失败: ' + JSON.stringify(res));
          result = false;
          break;
        }
        if (res.data.status !== "success") {
          logAndConsole('error', '下载引擎失败: ' + JSON.stringify(res));
          result = false;
          break;
        }
      }
      logAndConsole('info', '所有引擎下载结果: ' + JSON.stringify(result));
      return result;
    } catch (error) {
      logAndConsole('error', '下载引擎失败: ' + error.message);
      return false;
    }
  }

  // 5引擎配置（如适用)
  async CheckMemoryConfig() {
    if (!this.downloadConfig) {
      logAndConsole('error', '下载配置未加载');
      return false;
    }
    const res = await this._requestWithSchema({ method: 'get', url: 'engine/download/checkMemoryConfig' });
    if (res.code !== 200) {
      logAndConsole('error', '内存配置检查失败: ' + res.msg);
      return false;
    }
    this.downloadConfig.Memory = res.data.Size;
    await this.SetDefaultModel();
    return true;
  }

  // 6根据爱问学内置的奥丁配置（json配置）下载相应的模型
  async DownloadModel(){
    if (!this.downloadConfig) {
      logAndConsole('error', '下载配置未加载');
      return false;
    }
    try {
        let index = 0;
        if (this.downloadConfig.Memory > 16 && this.downloadConfig.Memory <= 32) {
          index = 1;
        }        
        if (this.downloadConfig.Memory > 32) {
          index = 2;
        }
        const embed = await this.downloadModelStream({
          engineName: this.downloadConfig.embed[index].api_flavor, 
          modelName: this.downloadConfig.embed[index].name, 
          modelType: "embed",
        });
        if (embed.code!==200) {
          return false;
        }
        if (embed.data.status !== "success") {
          logAndConsole('error', '下载embed模型失败: ' + this.downloadConfig.embed[index].name);
          return false;
        }
        logAndConsole('info', '下载embed模型成功: ' + this.downloadConfig.embed[index].name);
        const chat = await this.downloadModelStream({
          engineName: this.downloadConfig.chat[index].api_flavor, 
          modelName: this.downloadConfig.chat[index].name,
          modelType: "chat",
        });
        if (chat.code!==200) {
          return false;
        }
        if (chat.data.status !== "success") {
          logAndConsole('error', '下载chat模型失败: ' + this.downloadConfig.chat[index].name);
          return false;
        }
        logAndConsole('info', '下载chat模型成功: ' + this.downloadConfig.chat[index].name);
        return true;
    } catch (error) {
      logAndConsole('error', '下载模型失败: ' + error.message);
      return false;
    }
  }

  // 全检查 奥丁/引擎/模型
  async DownloadCheckDist() {
    if (!this.downloadConfig) {
      logAndConsole('error', 'DownloadCheckDist 下载配置未加载');
      return false;
    }
    try {
      let result = true;
      for (const engine of this.downloadConfig.support_engines) {
        const res = await this._requestWithSchema({ method: 'post', url: 'engine/download/checkDist', data: { engineName: engine } });
        if (res.code !== 200) {
          result = false;
          break;
        }
        if (res.data.status !== "success") {
          result = false;
          break;
        }
      }
      if (result) {
        await this.isOadinExistedAndUpdate(this.downloadConfig?.version);
        await this.ensureClient();
      }
      logAndConsole('info', '全检查结果: ' + result);
      if (result && (this.defaultEmbedModel === "" || this.defaultChatModel === "")) {
        await this.CheckMemoryConfig();
      }
      return result;
    } catch (error) {
      logAndConsole('error', '全检查失败: ' + error.message);
      return false;
    }    
  }

  // 赋值默认模型
  async SetDefaultModel() {
    if (!this.downloadConfig) {
      logAndConsole('error', 'DownloadCheckDist 下载配置未加载');
      return false;
    }
    let index = 0;
    if (this.downloadConfig.Memory > 16 && this.downloadConfig.Memory <= 32) {
      index = 1;
    }        
    if (this.downloadConfig.Memory > 32) {
      index = 2;
    }
    this.defaultEmbedModel = this.downloadConfig.embed[index].name;
    this.defaultChatModel = this.downloadConfig.chat[index].name;

    logAndConsole('info', 'SetDefaultModel embed: ' + this.defaultEmbedModel);
    logAndConsole('info', 'SetDefaultModel chat: ' + this.defaultChatModel);
  }

  // 获取默认模型
  GetDefaultModel() {
    return { embed: this.defaultEmbedModel, chat: this.defaultChatModel };
  }

  /**
    除了二进制文件是否存在，还要检查版本是否匹配
    版本匹配模式有两种，一种是根据配置文件，一种是根据sdk版本
  */
  async isOadinExistedAndUpdate(configVersion = null) {
    // 假设目标版本是oadin-installer-test-2.2.10，与当前已存在奥丁版本不符合，则需要更新
    let targetSubVersion = SUB_VERSION;
    if (configVersion && configVersion !== 'xxxxx') {
      targetSubVersion = configVersion;
    }
    let currentSubVersion = null;
    let fullStdout = ''; // 用于存储完整的stdout，以便后续解析
    logAndConsole('info', `isOadinExistedAndUpdate 目标版本: (${targetSubVersion})，开始检查是否需要更新...`);
    let oadinExecutable;
    try {
      const platform = tools.getPlatform();
      if (platform === 'unsupported' || !PLATFORM_CONFIG[platform]) {
        logAndConsole('error', 'isOadinExistedAndUpdate 不支持的平台');
        return false;
      }
      if (platform === 'win32') {
        const oadinDir = WIN_OADIN_PATH;
        oadinExecutable = path.join(oadinDir, 'oadin.exe');

        const originalPath = process.env.PATH;
        if (!process.env.PATH.includes(oadinDir)) {
          process.env.PATH = `${process.env.PATH}${path.delimiter}${oadinDir}`;
        }

        const { stdout } = await new Promise((resolve, reject) => {
          execFile(oadinExecutable, ['version'], { timeout: 5000 }, (error, stdout, stderr) => {
            process.env.PATH = originalPath; // 恢复 PATH

            if (error) {
              logAndConsole('error', `isOadinExistedAndUpdate 执行 'oadin version' 命令失败: ${error.message}, stderr: ${stderr.toString()}`);
              return reject(error);
            }
            resolve({ stdout: stdout.toString() });
          });
        });
        fullStdout = stdout.toString();
      } else if (platform === 'darwin') {
        oadinExecutable = MAC_OADIN_PATH; // 确保 MAC_OADIN_PATH 是正确的
        const { stdout } = await new Promise((resolve, reject) => {
          execFile(oadinExecutable, ['version'], { timeout: 5000 }, (error, stdout, stderr) => {
            if (error) {
              logAndConsole('error', `isOadinExistedAndUpdate 执行 'oadin version' 命令失败: ${error.message}, stderr: ${stderr.toString()}`);
              return reject(error);
            }
            resolve({ stdout: stdout.toString() });
          });
        });
        fullStdout = stdout.toString();
      } else {
        logAndConsole('warn', `isOadinExistedAndUpdate 不支持的平台，无法获取 Oadin 版本。`);
        return false;
      }

      // 解析子版本号
      const subVersionMatch = fullStdout.match(/Oadin SubVersion:\s*([^\r\n]+)/);
      if (subVersionMatch && subVersionMatch[1]) {
        currentSubVersion = subVersionMatch[1];
      }

      logAndConsole('info', `isOadinExistedAndUpdate Oadin 版本匹配。当前版本: (${currentSubVersion})`);
      if (currentSubVersion === targetSubVersion) {
        return true;
      }

      const { downloadUrl, installerFileName, userAgent } = PLATFORM_CONFIG[platform];
      const downloadUrlReplaced = downloadUrl.replace('latest', targetSubVersion);
      const userDir = os.homedir();
      const destDir = path.join(userDir, 'OadinInstaller');
      const dest = path.join(destDir, installerFileName);
      const options = { headers: { 'User-Agent': userAgent, }, };
      logAndConsole('info', `isOadinExistedAndUpdate 版本不匹配，开始下载并安装新版本。下载地址: ${downloadUrlReplaced}，目标路径: ${dest}`);
      const downloadOk = await downloadFile(downloadUrlReplaced, dest, options, 3);
      logAndConsole('info', `isOadinExistedAndUpdate 下载结果: ${downloadOk}`);
      if (downloadOk) {
        const installResult = await runInstallerByPlatform(dest);
        logAndConsole('info', `isOadinExistedAndUpdate 安装结果: ${installResult}`);
        return true;
      } else {
        logAndConsole('error', 'isOadinExistedAndUpdate 三次下载均失败，放弃安装。');
        return false;
      }
    } catch (error) {
      logAndConsole('error', `isOadinExistedAndUpdate 异常: ${error.message}`);
      return false;
    }
  }
}

module.exports = Oadin;